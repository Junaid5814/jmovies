# Jmovies

Premium dark-cinema movie discovery & streaming app built with Flutter.

- **Metadata**: The Movie Database (TMDB) — posters, synopsis, cast, ratings, genres.
- **Streaming**: your own backend/CDN, resolved separately from metadata
  (see `lib/data/services/stream_source_service.dart`). Ships with public
  Apple/Google test streams as a default so the player runs out of the box.

## Brand & Icon Spec

| Token | Value |
|---|---|
| Pure black | `#000000` |
| Deep charcoal | `#121212` / `#1C1C1E` |
| Crimson accent | `#E50914` (gradient to `#9B0710`) |
| Text primary | `#F5F5F7` |
| Text secondary | `#A1A1A6` |
| Gold (ratings) | `#FFC94A` |
| Headline font | Poppins (weights 600–700) |
| Body font | Inter |

Icon concept: a crimson film-reel ring with six sprocket holes around a dark
center hub, with a white "J" stroke cut through the hub — reads as both a
film reel and a monogram at small sizes. Source: `assets/icons/jmovies_logo.svg`.

To generate launcher icons from it:
1. Export the SVG to two PNGs (e.g. via any SVG-to-PNG tool or `rsvg-convert`):
   - `assets/icons/app_icon.png` (512×512, full icon on black background)
   - `assets/icons/app_icon_fg.png` (512×512, transparent background, icon only, for Android adaptive icons)
2. Run `dart run flutter_launcher_icons` (see build steps below).

## Project Structure

```
lib/
  core/
    constants/api_constants.dart     # TMDB movie+TV+OTT+regional endpoints
    theme/app_theme.dart             # Dark cinema ThemeData
  data/
    models/movie_model.dart          # TMDB movie metadata (no video URLs)
    models/tv_model.dart             # TMDB TV/season/episode metadata
    models/media_item.dart           # Unified Movie/TvShow wrapper for mixed feeds
    models/video_source_model.dart   # Stream sources: audio/quality/subs (your backend)
    services/tmdb_api_service.dart
    services/stream_source_service.dart
    repositories/movie_repository.dart
  providers/movie_providers.dart     # Riverpod state (3-mode home, OTT, regional)
  screens/
    home/home_screen.dart            # 🎬/📺/⚡ 3-mode pill switcher + all feeds
    details/details_screen.dart      # Unified: movies get Watch Now, TV/anime get
                                      # season chips + episode list
    player/player_screen.dart        # Native player: forMovie() / forEpisode()
    player/watch_webview_screen.dart # In-app WebView player (see below)
    search/search_screen.dart
  widgets/
    media_carousel.dart              # MediaHeroCarousel + MediaCarousel (Movie or TV)
    genre_chip.dart
  main.dart
```

### Content coverage

- **Movies vs TV switch**: `ContentMode` provider drives the Home screen between two tabs.
- **TV endpoints**: trending (`/trending/tv/day`), popular (`/tv/popular`), details
  (`/tv/{id}`), season detail with episodes (`/tv/{id}/season/{n}`).
- **OTT rows**: Netflix/Prime/HBO Max/Disney+/Apple TV+ via TMDB's
  `discover/tv?with_networks=`. This is pure metadata discovery (same idea
  as JustWatch) — it does not grant access to that platform's video files.
- **Regional hubs**: Bollywood/Punjabi/Tollywood/Tamil/Malayalam/Kannada via
  `with_original_language`.

### Player upgrades

- `PlayerScreen.forMovie(movie)` / `PlayerScreen.forEpisode(show:, episode:)`
  — the native `video_player`-based screen, still in the project as an
  alternative but **not currently wired to any button** (see below).
- Multi-server picker with automatic fallback (unchanged from v1)
- **Audio language picker**: since the base `video_player` plugin has no
  public API for in-stream HLS audio track switching, language selection
  re-points playback at a separate URL per `AudioTrack.url`. For true
  in-band ExoPlayer track selection, swap in a package that exposes it
  (see Notes below).
- **Quality picker**: switches between `QualityVariant` URLs (Auto/1080p/
  720p/480p), preserving playback position.
- **Subtitle picker**: lists embedded + external `.vtt`/`.srt` tracks from
  `VideoSource.subtitles`; selection is captured in state — wire an overlay
  renderer (see Notes) to actually paint the text.
- Double-tap left/right zones and buttons both trigger ±10s skip.
- Aspect ratio cycles Fit → Zoom → Stretch.
- 60s timeout on stream resolution and each source-init attempt, to
  tolerate slow networks before falling back/erroring.

### In-app WebView player (currently active)

`Watch Now` (movies) and episode taps (TV/anime) in `details_screen.dart`
currently navigate to `WatchWebviewScreen`, not the native player above.

```dart
WatchWebviewScreen(
  tmdbId: movie.id,
  title: movie.title,
  isTv: false,
)

WatchWebviewScreen(
  tmdbId: show.id,
  title: '...',
  isTv: true,
  seasonNumber: episode.seasonNumber,
  episodeNumber: episode.episodeNumber,
)
```

Internally it resolves the URL via `WebviewPlayerUrls`, pointed at
`WEBVIEW_PLAYER_BASE_URL` from `.env`:

- Movie: `{WEBVIEW_PLAYER_BASE_URL}/movie/{tmdbId}`
- Episode: `{WEBVIEW_PLAYER_BASE_URL}/tv/{tmdbId}/{seasonNumber}/{episodeNumber}`

This must point at a page **you host** that resolves the title
server-side and renders its own player — not a third-party embed site.
Features: forced landscape + portrait-on-exit, loading spinner with
progress, `onCreateWindow` returns `false` (blocks popup/ad windows), and
`shouldOverrideUrlLoading` only allows navigation that stays on the
original host (blocks ad redirects/affiliate links), plus a back button
that first tries in-page back history before popping the screen.

To switch back to the native player instead, replace the
`WatchWebviewScreen(...)` calls in `details_screen.dart` with
`PlayerScreen.forMovie(movie)` / `PlayerScreen.forEpisode(show:, episode:)`.

## Setup

```bash
# 1. Install Flutter (if needed): https://docs.flutter.dev/get-started/install

# 2. Get dependencies
flutter pub get

# 3. Configure API keys
cp .env.example .env
# then edit .env and paste your TMDB_ACCESS_TOKEN
# (free at https://www.themoviedb.org/settings/api)

# 4. Run in debug mode on a connected device/emulator
flutter run
```

## Wiring Your Streaming Backend

`StreamSourceService` expects, at `STREAM_BACKEND_URL`:

```
GET /api/stream/movie/{movieId}
GET /api/stream/tv/{tvId}/{season}/{episode}
```
```json
{
  "content_id": "123",
  "sources": [
    {
      "id": "cdn-a",
      "label": "1080p",
      "url": "https://cdn.example.com/123/master.m3u8",
      "format": "hls",
      "subtitles": [
        { "language": "English", "url": "https://cdn.example.com/123/en.vtt", "is_embedded": false }
      ],
      "audio_tracks": [
        { "track_id": "en", "language": "English", "url": "https://cdn.example.com/123/en/master.m3u8" },
        { "track_id": "hi", "language": "Hindi", "url": "https://cdn.example.com/123/hi/master.m3u8" }
      ],
      "qualities": [
        { "label": "Auto", "url": "https://cdn.example.com/123/master.m3u8" },
        { "label": "1080p", "url": "https://cdn.example.com/123/1080p.m3u8", "bitrate_kbps": 5000 },
        { "label": "720p", "url": "https://cdn.example.com/123/720p.m3u8", "bitrate_kbps": 2800 }
      ]
    },
    { "id": "cdn-b", "label": "720p", "url": "https://cdn2.example.com/123.mp4", "format": "mp4" }
  ]
}
```

Each top-level entry becomes a selectable "server" in the player's source
picker, and the player automatically advances to the next one if the
current source fails to initialize. `audio_tracks[].url` and
`qualities[].url` are optional — omit them if you don't have
per-language/per-bitrate renditions yet.

## Build a Release APK

```bash
# 1. Clean any previous build artifacts
flutter clean
flutter pub get

# 2. (Optional but recommended) generate launcher icons from the SVG-derived PNGs
dart run flutter_launcher_icons

# 3. Create/verify a signing key (first time only)
keytool -genkey -v -keystore ~/jmovies-release-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 -alias jmovies

# 4. Configure signing — create android/key.properties:
#    storePassword=YOUR_STORE_PASSWORD
#    keyPassword=YOUR_KEY_PASSWORD
#    keyAlias=jmovies
#    storeFile=/absolute/path/to/jmovies-release-key.jks
# and reference it from android/app/build.gradle's signingConfigs.

# 5. Build the release APK (split per ABI keeps file size down)
flutter build apk --release --split-per-abi

# Output:
# build/app/outputs/flutter-apk/app-armeabi-v7a-release.apk
# build/app/outputs/flutter-apk/app-arm64-v8a-release.apk
# build/app/outputs/flutter-apk/app-x86_64-release.apk

# Or a single universal APK instead:
flutter build apk --release

# Or an .aab for Play Store submission:
flutter build appbundle --release
# -> build/app/outputs/bundle/release/app-release.aab
```

## Notes

- The player screen uses `video_player` directly with fully custom controls
  (no `chewie` UI layer). `video_player` handles HLS and MP4 well; DASH
  support is device-dependent.
- **In-band audio track switching**: the base `video_player` plugin doesn't
  expose ExoPlayer's track-selection API. If you need true in-stream
  multi-audio (rather than separate per-language URLs), `better_player_plus`
  is the path — it wraps ExoPlayer on Android and surfaces track selection
  directly. Swapping it in only touches `player_screen.dart`; the
  `VideoSource`/`AudioTrack` models already carry what it needs.
- Subtitle rendering: `VideoSource.subtitles` selection is wired into the
  player's state; to actually paint `.vtt`/`.srt` text on screen, add a
  renderer package (e.g. `subtitle_wrapper`) in the subtitle handler in
  `player_screen.dart`.
- Remember to add `.env` and `android/key.properties` to `.gitignore`.
