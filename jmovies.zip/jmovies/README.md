# Jmovies

Premium dark-cinema movie discovery & streaming app built with Flutter.

- **Metadata**: The Movie Database (TMDB) — posters, synopsis, cast, ratings, genres.
- **Streaming**: your own backend/CDN, resolved separately from metadata
  (see `lib/data/services/stream_source_service.dart`). Ships with public
  Apple/Google test streams as a default so the player runs out of the box.

## Brand & Icon Spec

| Token | Value |
|---|---|
| Pure black | `#000000` |
| Deep charcoal | `#121212` / `#1C1C1E` |
| Crimson accent | `#E50914` (gradient to `#9B0710`) |
| Text primary | `#F5F5F7` |
| Text secondary | `#A1A1A6` |
| Gold (ratings) | `#FFC94A` |
| Headline font | Poppins (weights 600–700) |
| Body font | Inter |

Icon concept: a crimson film-reel ring with six sprocket holes around a dark
center hub, with a white "J" stroke cut through the hub — reads as both a
film reel and a monogram at small sizes. Source: `assets/icons/jmovies_logo.svg`.

To generate launcher icons from it:
1. Export the SVG to two PNGs (e.g. via any SVG-to-PNG tool or `rsvg-convert`):
   - `assets/icons/app_icon.png` (512×512, full icon on black background)
   - `assets/icons/app_icon_fg.png` (512×512, transparent background, icon only, for Android adaptive icons)
2. Run `dart run flutter_launcher_icons` (see build steps below).

## Project Structure

```
lib/
  core/
    constants/api_constants.dart     # TMDB endpoints, sample stream URLs
    theme/app_theme.dart             # Dark cinema ThemeData
  data/
    models/movie_model.dart          # TMDB metadata (no video URLs)
    models/video_source_model.dart   # Stream sources (from your backend)
    services/tmdb_api_service.dart
    services/stream_source_service.dart
    repositories/movie_repository.dart
  providers/movie_providers.dart     # Riverpod state
  screens/
    home/home_screen.dart
    details/details_screen.dart
    player/player_screen.dart
    search/search_screen.dart
  widgets/
    hero_carousel.dart
    movie_carousel.dart
    genre_chip.dart
  main.dart
```

## Setup

```bash
# 1. Install Flutter (if needed): https://docs.flutter.dev/get-started/install

# 2. Get dependencies
flutter pub get

# 3. Configure API keys
cp .env.example .env
# then edit .env and paste your TMDB_ACCESS_TOKEN
# (free at https://www.themoviedb.org/settings/api)

# 4. Run in debug mode on a connected device/emulator
flutter run
```

## Wiring Your Streaming Backend

`StreamSourceService` expects, at `STREAM_BACKEND_URL`:

```
GET /api/stream/{movieId}
```
```json
{
  "movie_id": 123,
  "sources": [
    { "id": "cdn-a", "label": "1080p", "url": "https://cdn.example.com/123/master.m3u8", "format": "hls",
      "subtitles": [{ "language": "English", "url": "https://cdn.example.com/123/en.vtt" }] },
    { "id": "cdn-b", "label": "720p", "url": "https://cdn2.example.com/123.mp4", "format": "mp4" }
  ]
}
```

Each entry becomes a selectable "server" in the player's source picker, and
the player automatically advances to the next one if the current source
fails to initialize.

## Build a Release APK

```bash
# 1. Clean any previous build artifacts
flutter clean
flutter pub get

# 2. (Optional but recommended) generate launcher icons from the SVG-derived PNGs
dart run flutter_launcher_icons

# 3. Create/verify a signing key (first time only)
keytool -genkey -v -keystore ~/jmovies-release-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 -alias jmovies

# 4. Configure signing — create android/key.properties:
#    storePassword=YOUR_STORE_PASSWORD
#    keyPassword=YOUR_KEY_PASSWORD
#    keyAlias=jmovies
#    storeFile=/absolute/path/to/jmovies-release-key.jks
# and reference it from android/app/build.gradle's signingConfigs.

# 5. Build the release APK (split per ABI keeps file size down)
flutter build apk --release --split-per-abi

# Output:
# build/app/outputs/flutter-apk/app-armeabi-v7a-release.apk
# build/app/outputs/flutter-apk/app-arm64-v8a-release.apk
# build/app/outputs/flutter-apk/app-x86_64-release.apk

# Or a single universal APK instead:
flutter build apk --release

# Or an .aab for Play Store submission:
flutter build appbundle --release
# -> build/app/outputs/bundle/release/app-release.aab
```

## Notes

- `video_player` + `chewie` handle HLS, DASH (device-dependent), and MP4.
  For heavier ABR/DRM needs later, `better_player_plus` (an actively
  maintained fork) is a drop-in-ish upgrade path.
- Subtitle rendering: wire `VideoSource.subtitles` into a `.vtt`/`.srt`
  renderer (e.g. `subtitle_wrapper` package) from the subtitle icon handler
  in `player_screen.dart`.
- Remember to add `.env` and `android/key.properties` to `.gitignore`.
