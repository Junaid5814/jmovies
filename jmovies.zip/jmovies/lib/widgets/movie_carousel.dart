import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';
import '../core/theme/app_theme.dart';
import '../data/models/movie_model.dart';
import '../screens/details/details_screen.dart';

class MovieCarousel extends StatelessWidget {
  final String title;
  final List<Movie> movies;
  final bool isLoading;

  const MovieCarousel({
    super.key,
    required this.title,
    required this.movies,
    this.isLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
          child: Text(title, style: Theme.of(context).textTheme.headlineMedium),
        ),
        SizedBox(
          height: 220,
          child: isLoading
              ? _buildShimmerRow()
              : ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  itemCount: movies.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 14),
                  itemBuilder: (context, index) {
                    final movie = movies[index];
                    return _PosterCard(movie: movie);
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildShimmerRow() {
    return ListView.separated(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      itemCount: 5,
      separatorBuilder: (_, __) => const SizedBox(width: 14),
      itemBuilder: (_, __) => Shimmer.fromColors(
        baseColor: AppColors.charcoalElevated,
        highlightColor: AppColors.surfaceCard,
        child: Container(
          width: 140,
          decoration: BoxDecoration(
            color: AppColors.charcoalElevated,
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
    );
  }
}

class _PosterCard extends StatelessWidget {
  final Movie movie;
  const _PosterCard({required this.movie});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => DetailsScreen(movieId: movie.id)),
      ),
      child: SizedBox(
        width: 140,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: CachedNetworkImage(
                imageUrl: movie.posterUrl,
                height: 180,
                width: 140,
                fit: BoxFit.cover,
                placeholder: (_, __) =>
                    Container(color: AppColors.charcoalElevated),
                errorWidget: (_, __, ___) => Container(
                  color: AppColors.charcoalElevated,
                  child: const Icon(Icons.movie_outlined,
                      color: AppColors.textMuted),
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              movie.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ],
        ),
      ),
    );
  }
}
