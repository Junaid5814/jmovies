import 'package:dio/dio.dart';
import '../../core/constants/api_constants.dart';
import '../models/video_source_model.dart';

/// Resolves playable video sources for a movie. This intentionally talks to
/// YOUR OWN backend (self-hosted API, Jellyfin/Plex, Cloudflare Stream,
/// S3+CloudFront signed URLs, etc.) — never TMDB, which has no video files.
///
/// Point [baseUrl] at your real backend. Until then, [fetchStreamBundle]
/// falls back to public HLS/MP4 test streams so the player screen is
/// runnable out of the box.
class StreamSourceService {
  final Dio _dio;
  final String? baseUrl;

  StreamSourceService({this.baseUrl})
      : _dio = Dio(BaseOptions(
          baseUrl: baseUrl ?? '',
          connectTimeout: const Duration(seconds: 8),
        ));

  Future<StreamBundle> fetchStreamBundle(int movieId) async {
    if (baseUrl == null || baseUrl!.isEmpty) {
      return _placeholderBundle(movieId);
    }

    try {
      // Expected contract for your backend:
      // GET {baseUrl}/api/stream/{movieId}
      // -> { "movie_id": 123, "sources": [ { id, label, url, format, subtitles[] } ] }
      final res = await _dio.get('/api/stream/$movieId');
      return StreamBundle.fromJson(res.data as Map<String, dynamic>);
    } on DioException catch (_) {
      // Automatic fallback: if your backend is unreachable, degrade to the
      // placeholder stream rather than leaving the player with nothing.
      return _placeholderBundle(movieId);
    }
  }

  StreamBundle _placeholderBundle(int movieId) => StreamBundle(
        movieId: movieId,
        sources: const [
          VideoSource(
            id: 'placeholder-hls',
            label: 'Auto (HLS)',
            url: SampleStreams.hlsAppleTest,
            format: StreamFormat.hls,
          ),
          VideoSource(
            id: 'placeholder-mp4-1',
            label: '1080p (MP4)',
            url: SampleStreams.mp4BigBuckBunny,
            format: StreamFormat.mp4,
          ),
          VideoSource(
            id: 'placeholder-mp4-2',
            label: '720p (MP4)',
            url: SampleStreams.mp4Sintel,
            format: StreamFormat.mp4,
          ),
        ],
      );
}
