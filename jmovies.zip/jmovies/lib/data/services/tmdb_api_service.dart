import 'package:dio/dio.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import '../../core/constants/api_constants.dart';
import '../models/movie_model.dart';

/// Thin wrapper around TMDB's REST API. This is the ONLY class allowed to
/// know about TMDB endpoints — screens/providers should go through
/// MovieRepository instead of calling this directly.
class TmdbApiService {
  final Dio _dio;

  TmdbApiService()
      : _dio = Dio(
          BaseOptions(
            baseUrl: ApiConstants.tmdbBaseUrl,
            connectTimeout: const Duration(seconds: 10),
            receiveTimeout: const Duration(seconds: 10),
            headers: {
              'Authorization': 'Bearer ${dotenv.env['TMDB_ACCESS_TOKEN']}',
              'Content-Type': 'application/json',
            },
          ),
        );

  Future<List<Movie>> fetchTrending() => _fetchList(ApiConstants.trending);

  Future<List<Movie>> fetchTopRated() => _fetchList(ApiConstants.topRated);

  Future<List<Movie>> fetchByGenre(int genreId) =>
      _fetchList(ApiConstants.discoverByGenre(genreId));

  Future<List<Movie>> search(String query) {
    if (query.trim().isEmpty) return Future.value([]);
    return _fetchList(ApiConstants.search(query));
  }

  Future<Movie> fetchDetails(int movieId) async {
    final res = await _dio.get(ApiConstants.movieDetails(movieId));
    return Movie.fromJson(res.data as Map<String, dynamic>);
  }

  Future<List<Movie>> _fetchList(String endpoint) async {
    try {
      final res = await _dio.get(endpoint);
      final results = (res.data['results'] as List<dynamic>)
          .map((json) => Movie.fromJson(json as Map<String, dynamic>))
          .toList();
      return results;
    } on DioException catch (e) {
      throw TmdbException(
        'Failed to load movies: ${e.response?.statusCode ?? e.message}',
      );
    }
  }
}

class TmdbException implements Exception {
  final String message;
  TmdbException(this.message);
  @override
  String toString() => message;
}
