import 'package:dio/dio.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import '../../core/constants/api_constants.dart';
import '../models/movie_model.dart';
import '../models/tv_model.dart';

/// Thin wrapper around TMDB's REST API. This is the ONLY class allowed to
/// know about TMDB endpoints — screens/providers should go through
/// MovieRepository instead of calling this directly.
class TmdbApiService {
  final Dio _dio;

  TmdbApiService()
      : _dio = Dio(
          BaseOptions(
            baseUrl: ApiConstants.tmdbBaseUrl,
            connectTimeout: const Duration(seconds: 10),
            receiveTimeout: const Duration(seconds: 10),
            headers: {
              'Authorization': 'Bearer ${dotenv.env['TMDB_ACCESS_TOKEN']}',
              'Content-Type': 'application/json',
            },
          ),
        );

  // --- Movies ---

  Future<List<Movie>> fetchTrendingMovies() =>
      _fetchMovieList(ApiConstants.trendingMovies);

  Future<List<Movie>> fetchTrendingMoviesDay() =>
      _fetchMovieList(ApiConstants.trendingMoviesDay);

  Future<List<Movie>> fetchTopRatedMovies() =>
      _fetchMovieList(ApiConstants.topRatedMovies);

  Future<List<Movie>> fetchMoviesByGenre(int genreId) =>
      _fetchMovieList(ApiConstants.discoverMoviesByGenre(genreId));

  Future<List<Movie>> fetchMoviesByLanguage(String languageCode,
          {String? region}) =>
      _fetchMovieList(ApiConstants.discoverByLanguage(languageCode,
          isTv: false, region: region));

  Future<List<Movie>> fetchMoviesByOriginCountry(String countryCode) =>
      _fetchMovieList(ApiConstants.discoverMoviesByOriginCountry(countryCode));

  Future<List<Movie>> fetchMoviesByGenreLanguage(
          int genreId, String languageCode) =>
      _fetchMovieList(
          ApiConstants.discoverMoviesByGenreLanguage(genreId, languageCode));

  Future<List<Movie>> searchMovies(String query) {
    if (query.trim().isEmpty) return Future.value([]);
    return _fetchMovieList(ApiConstants.searchMovies(query));
  }

  Future<Movie> fetchMovieDetails(int movieId) async {
    final res = await _dio.get(ApiConstants.movieDetails(movieId));
    return Movie.fromJson(res.data as Map<String, dynamic>);
  }

  // --- TV / Web Series ---

  Future<List<TvShow>> fetchTrendingTv() =>
      _fetchTvList(ApiConstants.trendingTv);

  Future<List<TvShow>> fetchPopularTv() => _fetchTvList(ApiConstants.popularTv);

  Future<List<TvShow>> fetchTopRatedTv() => _fetchTvList(ApiConstants.topRatedTv);

  Future<List<TvShow>> fetchTvByGenre(int genreId) =>
      _fetchTvList(ApiConstants.discoverTvByGenre(genreId));

  Future<List<TvShow>> fetchTvByNetwork(int networkId) =>
      _fetchTvList(ApiConstants.discoverTvByNetwork(networkId));

  Future<List<TvShow>> fetchTvByLanguage(String languageCode,
          {String? region}) =>
      _fetchTvList(ApiConstants.discoverByLanguage(languageCode,
          isTv: true, region: region));

  Future<List<TvShow>> fetchTvByOriginCountry(String countryCode,
          {String? languageCode}) =>
      _fetchTvList(ApiConstants.discoverTvByOriginCountry(countryCode,
          languageCode: languageCode));

  Future<List<TvShow>> fetchTvByGenreLanguage(
    int genreId,
    String languageCode, {
    String sortBy = 'popularity.desc',
    int? minVoteCount,
  }) =>
      _fetchTvList(ApiConstants.discoverTvByGenreLanguage(
        genreId,
        languageCode,
        sortBy: sortBy,
        minVoteCount: minVoteCount,
      ));

  Future<List<TvShow>> searchTv(String query) {
    if (query.trim().isEmpty) return Future.value([]);
    return _fetchTvList(ApiConstants.searchTv(query));
  }

  Future<TvShow> fetchTvDetails(int tvId) async {
    final res = await _dio.get(ApiConstants.tvDetails(tvId));
    return TvShow.fromJson(res.data as Map<String, dynamic>);
  }

  Future<SeasonDetail> fetchSeasonDetail(int tvId, int seasonNumber) async {
    try {
      final res = await _dio.get(ApiConstants.tvSeason(tvId, seasonNumber));
      return SeasonDetail.fromJson(res.data as Map<String, dynamic>);
    } on DioException catch (e) {
      throw TmdbException(
        'Failed to load season $seasonNumber: ${e.response?.statusCode ?? e.message}',
      );
    }
  }

  // --- Shared helpers ---

  Future<List<Movie>> _fetchMovieList(String endpoint) async {
    try {
      final res = await _dio.get(endpoint);
      return (res.data['results'] as List<dynamic>)
          .map((json) => Movie.fromJson(json as Map<String, dynamic>))
          .toList();
    } on DioException catch (e) {
      throw TmdbException(
        'Failed to load movies: ${e.response?.statusCode ?? e.message}',
      );
    }
  }

  Future<List<TvShow>> _fetchTvList(String endpoint) async {
    try {
      final res = await _dio.get(endpoint);
      return (res.data['results'] as List<dynamic>)
          .map((json) => TvShow.fromJson(json as Map<String, dynamic>))
          .toList();
    } on DioException catch (e) {
      throw TmdbException(
        'Failed to load TV shows: ${e.response?.statusCode ?? e.message}',
      );
    }
  }
}

class TmdbException implements Exception {
  final String message;
  TmdbException(this.message);
  @override
  String toString() => message;
}
