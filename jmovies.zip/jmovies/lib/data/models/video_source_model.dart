import 'package:equatable/equatable.dart';

enum StreamFormat { hls, dash, mp4 }

/// A single playable source for a given movie, returned by YOUR OWN
/// backend/CDN (not TMDB). Keeping this separate from [Movie] means the
/// metadata layer and the streaming layer can evolve independently —
/// e.g. you can swap CDNs without touching TMDB integration at all.
class VideoSource extends Equatable {
  final String id;
  final String label; // e.g. "1080p", "Auto", "720p"
  final String url;
  final StreamFormat format;
  final List<SubtitleTrack> subtitles;

  const VideoSource({
    required this.id,
    required this.label,
    required this.url,
    required this.format,
    this.subtitles = const [],
  });

  factory VideoSource.fromJson(Map<String, dynamic> json) {
    return VideoSource(
      id: json['id'] as String,
      label: (json['label'] ?? 'Default') as String,
      url: json['url'] as String,
      format: _formatFromString(json['format'] as String? ?? 'hls'),
      subtitles: (json['subtitles'] as List<dynamic>? ?? [])
          .map((s) => SubtitleTrack.fromJson(s as Map<String, dynamic>))
          .toList(),
    );
  }

  static StreamFormat _formatFromString(String s) {
    switch (s.toLowerCase()) {
      case 'dash':
        return StreamFormat.dash;
      case 'mp4':
        return StreamFormat.mp4;
      default:
        return StreamFormat.hls;
    }
  }

  @override
  List<Object?> get props => [id, url];
}

class SubtitleTrack extends Equatable {
  final String language; // e.g. "English"
  final String url; // .vtt or .srt

  const SubtitleTrack({required this.language, required this.url});

  factory SubtitleTrack.fromJson(Map<String, dynamic> json) => SubtitleTrack(
        language: (json['language'] ?? '') as String,
        url: (json['url'] ?? '') as String,
      );

  @override
  List<Object?> get props => [language, url];
}

/// Bundles the qualities/formats available for one movie ID, as returned
/// by your backend endpoint, e.g. GET /api/stream/{movieId}
class StreamBundle extends Equatable {
  final int movieId;
  final List<VideoSource> sources;

  const StreamBundle({required this.movieId, required this.sources});

  VideoSource? get defaultSource => sources.isNotEmpty ? sources.first : null;

  factory StreamBundle.fromJson(Map<String, dynamic> json) => StreamBundle(
        movieId: json['movie_id'] as int,
        sources: (json['sources'] as List<dynamic>)
            .map((s) => VideoSource.fromJson(s as Map<String, dynamic>))
            .toList(),
      );

  @override
  List<Object?> get props => [movieId];
}
