import 'package:equatable/equatable.dart';
import '../../core/constants/api_constants.dart';
import 'movie_model.dart';
import 'tv_model.dart';

/// Unified view over a [Movie] or a [TvShow] so the home feed, hero
/// banners, and carousels can render mixed content without branching on
/// type everywhere. Always carries [isTv] so navigation can route to the
/// correct details screen and TMDB endpoint (`/movie/{id}` vs `/tv/{id}`).
class MediaItem extends Equatable {
  final int id;
  final String title; // Movie.title or TvShow.name
  final String overview;
  final String? posterPath;
  final String? backdropPath;
  final double voteAverage;
  final String dateString; // release_date or first_air_date
  final bool isTv;
  final List<int> genreIds;

  const MediaItem({
    required this.id,
    required this.title,
    required this.overview,
    this.posterPath,
    this.backdropPath,
    this.voteAverage = 0,
    this.dateString = '',
    required this.isTv,
    this.genreIds = const [],
  });

  String get posterUrl => posterPath == null
      ? ''
      : '${ApiConstants.tmdbImageBaseUrl}/${ApiConstants.posterSize}$posterPath';

  String get backdropUrl => backdropPath == null
      ? ''
      : '${ApiConstants.tmdbImageBaseUrl}/${ApiConstants.backdropSize}$backdropPath';

  String get year => dateString.isNotEmpty ? dateString.split('-').first : '—';

  factory MediaItem.fromMovie(Movie movie) => MediaItem(
        id: movie.id,
        title: movie.title,
        overview: movie.overview,
        posterPath: movie.posterPath,
        backdropPath: movie.backdropPath,
        voteAverage: movie.voteAverage,
        dateString: movie.releaseDate,
        isTv: false,
        genreIds: movie.genreIds,
      );

  factory MediaItem.fromTv(TvShow show) => MediaItem(
        id: show.id,
        title: show.name,
        overview: show.overview,
        posterPath: show.posterPath,
        backdropPath: show.backdropPath,
        voteAverage: show.voteAverage,
        dateString: show.firstAirDate,
        isTv: true,
        genreIds: show.genreIds,
      );

  static List<MediaItem> fromMovies(List<Movie> movies) =>
      movies.map(MediaItem.fromMovie).toList();

  static List<MediaItem> fromTvShows(List<TvShow> shows) =>
      shows.map(MediaItem.fromTv).toList();

  @override
  List<Object?> get props => [id, isTv];
}
