import '../models/movie_model.dart';
import '../models/video_source_model.dart';
import '../services/tmdb_api_service.dart';
import '../services/stream_source_service.dart';

/// Single entry point the UI/providers talk to. Keeps the metadata source
/// (TMDB) and the streaming source (your backend) cleanly separated while
/// presenting one simple API to the rest of the app.
class MovieRepository {
  final TmdbApiService _tmdb;
  final StreamSourceService _streams;

  MovieRepository({TmdbApiService? tmdb, StreamSourceService? streams})
      : _tmdb = tmdb ?? TmdbApiService(),
        _streams = streams ?? StreamSourceService();

  Future<List<Movie>> getTrending() => _tmdb.fetchTrending();
  Future<List<Movie>> getTopRated() => _tmdb.fetchTopRated();
  Future<List<Movie>> getByGenre(int genreId) => _tmdb.fetchByGenre(genreId);
  Future<List<Movie>> search(String query) => _tmdb.search(query);
  Future<Movie> getDetails(int movieId) => _tmdb.fetchDetails(movieId);

  Future<StreamBundle> getStreamBundle(int movieId) =>
      _streams.fetchStreamBundle(movieId);
}
