import '../models/movie_model.dart';
import '../models/tv_model.dart';
import '../models/video_source_model.dart';
import '../services/tmdb_api_service.dart';
import '../services/stream_source_service.dart';

/// Single entry point the UI/providers talk to. Keeps the metadata source
/// (TMDB) and the streaming source (your backend) cleanly separated while
/// presenting one simple API to the rest of the app.
class MovieRepository {
  final TmdbApiService _tmdb;
  final StreamSourceService _streams;

  MovieRepository({TmdbApiService? tmdb, StreamSourceService? streams})
      : _tmdb = tmdb ?? TmdbApiService(),
        _streams = streams ?? StreamSourceService();

  // --- Movies ---
  Future<List<Movie>> getTrendingMovies() => _tmdb.fetchTrendingMovies();
  Future<List<Movie>> getTrendingMoviesDay() => _tmdb.fetchTrendingMoviesDay();
  Future<List<Movie>> getTopRatedMovies() => _tmdb.fetchTopRatedMovies();
  Future<List<Movie>> getMoviesByGenre(int genreId) =>
      _tmdb.fetchMoviesByGenre(genreId);
  Future<List<Movie>> getMoviesByLanguage(String lang, {String? region}) =>
      _tmdb.fetchMoviesByLanguage(lang, region: region);
  Future<List<Movie>> getMoviesByOriginCountry(String countryCode) =>
      _tmdb.fetchMoviesByOriginCountry(countryCode);
  Future<List<Movie>> getMoviesByGenreLanguage(int genreId, String lang) =>
      _tmdb.fetchMoviesByGenreLanguage(genreId, lang);
  Future<List<Movie>> searchMovies(String query) => _tmdb.searchMovies(query);
  Future<Movie> getMovieDetails(int movieId) =>
      _tmdb.fetchMovieDetails(movieId);
  Future<StreamBundle> getMovieStreamBundle(int movieId) =>
      _streams.fetchMovieStreamBundle(movieId);

  // --- TV / Web Series / Anime (TV) ---
  Future<List<TvShow>> getTrendingTv() => _tmdb.fetchTrendingTv();
  Future<List<TvShow>> getPopularTv() => _tmdb.fetchPopularTv();
  Future<List<TvShow>> getTopRatedTv() => _tmdb.fetchTopRatedTv();
  Future<List<TvShow>> getTvByGenre(int genreId) =>
      _tmdb.fetchTvByGenre(genreId);
  Future<List<TvShow>> getTvByNetwork(int networkId) =>
      _tmdb.fetchTvByNetwork(networkId);
  Future<List<TvShow>> getTvByLanguage(String lang, {String? region}) =>
      _tmdb.fetchTvByLanguage(lang, region: region);
  Future<List<TvShow>> getTvByOriginCountry(String countryCode,
          {String? languageCode}) =>
      _tmdb.fetchTvByOriginCountry(countryCode, languageCode: languageCode);
  Future<List<TvShow>> getTvByGenreLanguage(
    int genreId,
    String lang, {
    String sortBy = 'popularity.desc',
    int? minVoteCount,
  }) =>
      _tmdb.fetchTvByGenreLanguage(genreId, lang,
          sortBy: sortBy, minVoteCount: minVoteCount);
  Future<List<TvShow>> searchTv(String query) => _tmdb.searchTv(query);
  Future<TvShow> getTvDetails(int tvId) => _tmdb.fetchTvDetails(tvId);
  Future<SeasonDetail> getSeasonDetail(int tvId, int seasonNumber) =>
      _tmdb.fetchSeasonDetail(tvId, seasonNumber);
  Future<StreamBundle> getEpisodeStreamBundle(
    int tvId,
    int seasonNumber,
    int episodeNumber,
  ) =>
      _streams.fetchEpisodeStreamBundle(tvId, seasonNumber, episodeNumber);
}
