/// TMDB is used ONLY for legal metadata: posters, synopsis, cast, ratings.
/// It is never used to source video files — TMDB does not provide those.
class ApiConstants {
  ApiConstants._();

  // Get a free key at https://www.themoviedb.org/settings/api
  // Loaded from .env via flutter_dotenv — never hardcode real keys in source.
  static const String tmdbBaseUrl = 'https://api.themoviedb.org/3';
  static const String tmdbImageBaseUrl = 'https://image.tmdb.org/t/p';

  // Image sizes TMDB supports
  static const String posterSize = 'w500';
  static const String backdropSize = 'w1280';

  static const String trending = '/trending/movie/week';
  static const String topRated = '/movie/top_rated';
  static String discoverByGenre(int genreId) =>
      '/discover/movie?with_genres=$genreId';
  static String search(String query) =>
      '/search/movie?query=${Uri.encodeComponent(query)}';
  static String movieDetails(int id) => '/movie/$id?append_to_response=credits';

  // TMDB genre IDs (standard, public)
  static const int genreAction = 28;
  static const int genreComedy = 35;
  static const int genreDrama = 18;
  static const int genreSciFi = 878;
  static const int genreHorror = 27;
  static const int genreAnimation = 16;
}

/// Placeholder / sample video sources used ONLY as defaults until a movie
/// record is wired to your own backend's stream URL. These are Apple's and
/// Google's publicly published test streams, safe to ship in a demo build.
class SampleStreams {
  SampleStreams._();

  static const String hlsAppleTest =
      'https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8';

  static const String mp4BigBuckBunny =
      'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';

  static const String mp4Sintel =
      'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4';
}
