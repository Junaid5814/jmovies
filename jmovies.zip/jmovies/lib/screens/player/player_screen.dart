import 'dart:async';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/movie_model.dart';
import '../../data/models/video_source_model.dart';
import '../../providers/movie_providers.dart';

/// Fullscreen streaming player.
///
/// Source-switching model: [StreamBundle.sources] lists the available
/// playable sources for this movie (e.g. different CDN edges/qualities
/// from YOUR backend). The user can switch between them from the source
/// sheet; if the currently selected source fails to load, we automatically
/// advance to the next one in the list.
class PlayerScreen extends ConsumerStatefulWidget {
  final Movie movie;
  const PlayerScreen({super.key, required this.movie});

  @override
  ConsumerState<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends ConsumerState<PlayerScreen> {
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;
  List<VideoSource> _sources = [];
  int _currentIndex = 0;
  bool _isInitializing = true;
  String? _errorMessage;
  double _playbackSpeed = 1.0;
  BoxFit _aspectFit = BoxFit.contain;

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    WakelockPlus.enable();
    _loadStreamBundle();
  }

  Future<void> _loadStreamBundle() async {
    try {
      final bundle =
          await ref.read(movieRepositoryProvider).getStreamBundle(widget.movie.id);
      if (bundle.sources.isEmpty) {
        setState(() {
          _errorMessage = 'No playable sources found for this title.';
          _isInitializing = false;
        });
        return;
      }
      _sources = bundle.sources;
      await _initPlayer(0);
    } catch (e) {
      setState(() {
        _errorMessage = 'Could not reach the streaming backend.';
        _isInitializing = false;
      });
    }
  }

  /// Initializes the player for source [index]. On failure, automatically
  /// falls back to the next available source (Server Alpha -> Beta -> Gamma).
  Future<void> _initPlayer(int index, {int attempt = 0}) async {
    if (index >= _sources.length) {
      setState(() {
        _errorMessage = 'All sources failed. Please try again later.';
        _isInitializing = false;
      });
      return;
    }

    setState(() {
      _isInitializing = true;
      _errorMessage = null;
      _currentIndex = index;
    });

    final source = _sources[index];
    await _disposeControllers();

    final controller = VideoPlayerController.networkUrl(Uri.parse(source.url));

    try {
      await controller.initialize().timeout(const Duration(seconds: 12));

      final chewie = ChewieController(
        videoPlayerController: controller,
        autoPlay: true,
        looping: false,
        showControls: false, // we render fully custom controls below
        aspectRatio: controller.value.aspectRatio,
        errorBuilder: (context, errorMessage) => _PlayerErrorView(
          message: errorMessage,
        ),
      );

      setState(() {
        _videoController = controller;
        _chewieController = chewie;
        _isInitializing = false;
      });
    } catch (e) {
      // Automatic fallback logic: this source is slow/offline, try the next.
      if (index + 1 < _sources.length) {
        _initPlayer(index + 1);
      } else {
        setState(() {
          _errorMessage =
              'Source "${source.label}" failed and no fallback sources remain.';
          _isInitializing = false;
        });
      }
    }
  }

  Future<void> _disposeControllers() async {
    _chewieController?.dispose();
    await _videoController?.dispose();
    _chewieController = null;
    _videoController = null;
  }

  void _showSourceSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.charcoal,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('Select Server',
                    style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600)),
              ),
              ..._sources.asMap().entries.map((entry) {
                final i = entry.key;
                final source = entry.value;
                final isActive = i == _currentIndex;
                return ListTile(
                  leading: Icon(
                    isActive ? Icons.play_circle_fill : Icons.dns_rounded,
                    color: isActive ? AppColors.crimson : AppColors.textSecondary,
                  ),
                  title: Text(
                    // Presented to the user as "Server Alpha/Beta/Gamma" style
                    // labels even though internally it's just index order.
                    _serverLabel(i, source),
                    style: const TextStyle(color: Colors.white),
                  ),
                  subtitle: Text(source.format.name.toUpperCase(),
                      style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
                  trailing: isActive
                      ? const Icon(Icons.check_circle, color: AppColors.crimson)
                      : null,
                  onTap: () {
                    Navigator.pop(context);
                    if (i != _currentIndex) _initPlayer(i);
                  },
                );
              }),
              const SizedBox(height: 12),
            ],
          ),
        );
      },
    );
  }

  String _serverLabel(int index, VideoSource source) {
    const greekNames = ['Server Alpha', 'Server Beta', 'Server Gamma', 'Server Delta'];
    final name = index < greekNames.length ? greekNames[index] : 'Server ${index + 1}';
    return '$name · ${source.label}';
  }

  void _showSpeedSheet() {
    const speeds = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.charcoal,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: speeds.map((s) {
            return ListTile(
              title: Text('${s}x', style: const TextStyle(color: Colors.white)),
              trailing: _playbackSpeed == s
                  ? const Icon(Icons.check, color: AppColors.crimson)
                  : null,
              onTap: () {
                setState(() => _playbackSpeed = s);
                _videoController?.setPlaybackSpeed(s);
                Navigator.pop(context);
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  @override
  void dispose() {
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    WakelockPlus.disable();
    _disposeControllers();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            Center(child: _buildPlayerBody()),
            Positioned(
              top: 8,
              left: 8,
              child: IconButton(
                icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPlayerBody() {
    if (_isInitializing) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: const [
          CircularProgressIndicator(color: AppColors.crimson),
          SizedBox(height: 16),
          Text('Connecting to stream…', style: TextStyle(color: Colors.white70)),
        ],
      );
    }

    if (_errorMessage != null) {
      return _PlayerErrorView(
        message: _errorMessage!,
        onRetry: () => _initPlayer(0),
      );
    }

    if (_videoController == null || !_videoController!.value.isInitialized) {
      return const SizedBox.shrink();
    }

    return _CustomVideoControls(
      controller: _videoController!,
      movieTitle: widget.movie.title,
      currentSourceLabel: _serverLabel(_currentIndex, _sources[_currentIndex]),
      aspectFit: _aspectFit,
      onToggleAspect: () {
        setState(() {
          _aspectFit = _aspectFit == BoxFit.contain ? BoxFit.cover : BoxFit.contain;
        });
      },
      onOpenServers: _showSourceSheet,
      onOpenSpeed: _showSpeedSheet,
    );
  }
}

/// Fully custom playback control surface (no chewie default UI):
/// play/pause, ±10s skip, scrub bar, aspect toggle, speed, server picker.
class _CustomVideoControls extends StatefulWidget {
  final VideoPlayerController controller;
  final String movieTitle;
  final String currentSourceLabel;
  final BoxFit aspectFit;
  final VoidCallback onToggleAspect;
  final VoidCallback onOpenServers;
  final VoidCallback onOpenSpeed;

  const _CustomVideoControls({
    required this.controller,
    required this.movieTitle,
    required this.currentSourceLabel,
    required this.aspectFit,
    required this.onToggleAspect,
    required this.onOpenServers,
    required this.onOpenSpeed,
  });

  @override
  State<_CustomVideoControls> createState() => _CustomVideoControlsState();
}

class _CustomVideoControlsState extends State<_CustomVideoControls> {
  bool _controlsVisible = true;
  Timer? _hideTimer;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onTick);
    _scheduleHide();
  }

  void _onTick() => setState(() {});

  void _scheduleHide() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 4), () {
      if (mounted) setState(() => _controlsVisible = false);
    });
  }

  void _toggleControls() {
    setState(() => _controlsVisible = !_controlsVisible);
    if (_controlsVisible) _scheduleHide();
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    widget.controller.removeListener(_onTick);
    super.dispose();
  }

  String _formatDuration(Duration d) {
    String two(int n) => n.toString().padLeft(2, '0');
    final h = d.inHours;
    final m = d.inMinutes.remainder(60);
    final s = d.inSeconds.remainder(60);
    return h > 0 ? '$h:${two(m)}:${two(s)}' : '${two(m)}:${two(s)}';
  }

  @override
  Widget build(BuildContext context) {
    final value = widget.controller.value;
    final position = value.position;
    final duration = value.duration;

    return GestureDetector(
      onTap: _toggleControls,
      child: Stack(
        fit: StackFit.expand,
        children: [
          FittedBox(
            fit: widget.aspectFit == BoxFit.cover ? BoxFit.cover : BoxFit.contain,
            child: SizedBox(
              width: value.size.width,
              height: value.size.height,
              child: VideoPlayer(widget.controller),
            ),
          ),
          if (_controlsVisible)
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.55),
                    Colors.transparent,
                    Colors.transparent,
                    Colors.black.withOpacity(0.7),
                  ],
                  stops: const [0, 0.25, 0.6, 1],
                ),
              ),
              child: SafeArea(
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(56, 8, 16, 0),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              widget.movieTitle,
                              style: const TextStyle(
                                  color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          TextButton.icon(
                            onPressed: widget.onOpenServers,
                            icon: const Icon(Icons.dns_rounded, color: Colors.white, size: 18),
                            label: Text(widget.currentSourceLabel,
                                style: const TextStyle(color: Colors.white, fontSize: 12)),
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _controlIcon(Icons.replay_10_rounded, () {
                          widget.controller.seekTo(position - const Duration(seconds: 10));
                          _scheduleHide();
                        }),
                        const SizedBox(width: 32),
                        _controlIcon(
                          value.isPlaying ? Icons.pause_circle_filled : Icons.play_circle_filled,
                          () {
                            value.isPlaying
                                ? widget.controller.pause()
                                : widget.controller.play();
                            _scheduleHide();
                          },
                          size: 64,
                        ),
                        const SizedBox(width: 32),
                        _controlIcon(Icons.forward_10_rounded, () {
                          widget.controller.seekTo(position + const Duration(seconds: 10));
                          _scheduleHide();
                        }),
                      ],
                    ),
                    const Spacer(),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Row(
                        children: [
                          Text(_formatDuration(position),
                              style: const TextStyle(color: Colors.white70, fontSize: 12)),
                          Expanded(
                            child: SliderTheme(
                              data: SliderTheme.of(context).copyWith(
                                trackHeight: 2,
                                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                              ),
                              child: Slider(
                                min: 0,
                                max: duration.inMilliseconds.toDouble().clamp(1, double.infinity),
                                value: position.inMilliseconds
                                    .clamp(0, duration.inMilliseconds)
                                    .toDouble(),
                                onChanged: (v) {
                                  widget.controller.seekTo(Duration(milliseconds: v.toInt()));
                                },
                              ),
                            ),
                          ),
                          Text(_formatDuration(duration),
                              style: const TextStyle(color: Colors.white70, fontSize: 12)),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          TextButton.icon(
                            onPressed: widget.onOpenSpeed,
                            icon: const Icon(Icons.speed_rounded, color: Colors.white, size: 18),
                            label: Text('${widget.controller.value.playbackSpeed}x',
                                style: const TextStyle(color: Colors.white, fontSize: 12)),
                          ),
                          const SizedBox(width: 8),
                          TextButton.icon(
                            onPressed: widget.onToggleAspect,
                            icon: const Icon(Icons.aspect_ratio_rounded, color: Colors.white, size: 18),
                            label: Text(
                              widget.aspectFit == BoxFit.contain ? 'Fit' : 'Fill',
                              style: const TextStyle(color: Colors.white, fontSize: 12),
                            ),
                          ),
                          const SizedBox(width: 8),
                          IconButton(
                            icon: const Icon(Icons.subtitles_outlined, color: Colors.white, size: 20),
                            onPressed: () {
                              // Hook up to VideoSource.subtitles: load a .vtt/.srt
                              // track here via a subtitle-rendering package
                              // (e.g. subtitle_wrapper) or platform captions API.
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Subtitle track picker goes here')),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _controlIcon(IconData icon, VoidCallback onTap, {double size = 44}) {
    return GestureDetector(
      onTap: onTap,
      child: Icon(icon, color: Colors.white, size: size),
    );
  }
}

class _PlayerErrorView extends StatelessWidget {
  final String message;
  final VoidCallback? onRetry;
  const _PlayerErrorView({required this.message, this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.error_outline_rounded, color: AppColors.crimson, size: 40),
          const SizedBox(height: 12),
          Text(message, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
          if (onRetry != null) ...[
            const SizedBox(height: 16),
            ElevatedButton(onPressed: onRetry, child: const Text('Retry')),
          ],
        ],
      ),
    );
  }
}
