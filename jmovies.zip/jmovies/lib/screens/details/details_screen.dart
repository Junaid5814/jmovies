import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/movie_model.dart';
import '../../providers/movie_providers.dart';
import '../player/player_screen.dart';

class DetailsScreen extends ConsumerWidget {
  final int movieId;
  const DetailsScreen({super.key, required this.movieId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final detailsAsync = ref.watch(movieDetailsProvider(movieId));

    return Scaffold(
      backgroundColor: AppColors.pureBlack,
      body: detailsAsync.when(
        loading: () => const Center(
          child: CircularProgressIndicator(color: AppColors.crimson),
        ),
        error: (e, _) => Center(
          child: Text('Failed to load details', style: TextStyle(color: AppColors.textSecondary)),
        ),
        data: (movie) => _DetailsBody(movie: movie),
      ),
    );
  }
}

class _DetailsBody extends StatelessWidget {
  final Movie movie;
  const _DetailsBody({required this.movie});

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverAppBar(
          expandedHeight: 420,
          pinned: true,
          backgroundColor: AppColors.pureBlack,
          leading: const BackButton(color: Colors.white),
          flexibleSpace: FlexibleSpaceBar(
            background: Stack(
              fit: StackFit.expand,
              children: [
                CachedNetworkImage(
                  imageUrl: movie.backdropUrl,
                  fit: BoxFit.cover,
                  errorWidget: (_, __, ___) =>
                      Container(color: AppColors.charcoalElevated),
                ),
                DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        AppColors.pureBlack.withOpacity(0.6),
                        AppColors.pureBlack,
                      ],
                      stops: const [0.3, 0.75, 1.0],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 32),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(movie.title, style: Theme.of(context).textTheme.displayLarge),
                const SizedBox(height: 10),
                Row(
                  children: [
                    const Icon(Icons.star_rounded, color: AppColors.gold, size: 20),
                    const SizedBox(width: 4),
                    Text(movie.voteAverage.toStringAsFixed(1),
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                    const SizedBox(width: 16),
                    Text(movie.releaseYear, style: const TextStyle(color: AppColors.textSecondary)),
                    if (movie.runtimeMinutes > 0) ...[
                      const SizedBox(width: 16),
                      Text('${movie.runtimeMinutes} min',
                          style: const TextStyle(color: AppColors.textSecondary)),
                    ],
                  ],
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => PlayerScreen(movie: movie),
                      ),
                    ),
                    icon: const Icon(Icons.play_arrow_rounded, size: 28),
                    label: const Text('Watch Now'),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                  ),
                ),
                const SizedBox(height: 28),
                Text('Synopsis', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                Text(
                  movie.overview.isEmpty ? 'No synopsis available.' : movie.overview,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                if (movie.cast.isNotEmpty) ...[
                  const SizedBox(height: 28),
                  Text('Cast', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 110,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: movie.cast.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 14),
                      itemBuilder: (context, index) {
                        final actor = movie.cast[index];
                        return SizedBox(
                          width: 72,
                          child: Column(
                            children: [
                              CircleAvatar(
                                radius: 32,
                                backgroundColor: AppColors.charcoalElevated,
                                backgroundImage: actor.profileUrl.isNotEmpty
                                    ? CachedNetworkImageProvider(actor.profileUrl)
                                    : null,
                                child: actor.profileUrl.isEmpty
                                    ? const Icon(Icons.person, color: AppColors.textMuted)
                                    : null,
                              ),
                              const SizedBox(height: 6),
                              Text(
                                actor.name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(color: Colors.white, fontSize: 12),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ],
    );
  }
}
