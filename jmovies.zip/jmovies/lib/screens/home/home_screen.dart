import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/media_item.dart';
import '../../providers/movie_providers.dart';
import '../../widgets/media_carousel.dart';
import '../search/search_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mode = ref.watch(homeModeProvider);

    return Scaffold(
      backgroundColor: AppColors.pureBlack,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(context),
            const SizedBox(height: 14),
            const _ModePillSwitcher(),
            const SizedBox(height: 4),
            Expanded(
              child: IndexedStack(
                index: mode.index,
                children: const [
                  _MoviesFeed(),
                  _SeriesFeed(),
                  _AnimeFeed(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              SvgPicture.asset('assets/icons/jmovies_logo.svg', height: 30),
              const SizedBox(width: 10),
              Text('Jmovies',
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontSize: 22)),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.search_rounded, color: Colors.white, size: 26),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SearchScreen()),
            ),
          ),
        ],
      ),
    );
  }
}

/// Top 3-mode pill switcher: Movies / Series & Dramas / Anime.
/// Switching modes only updates [homeModeProvider] — the [IndexedStack]
/// above keeps all three feeds alive, so changing tabs never reloads the
/// scaffold or re-fetches data that's already loaded.
class _ModePillSwitcher extends ConsumerWidget {
  const _ModePillSwitcher();

  static const _pills = [
    (mode: HomeMode.movies, label: '🎬 Movies'),
    (mode: HomeMode.series, label: '📺 Series & Dramas'),
    (mode: HomeMode.anime, label: '⚡ Anime'),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mode = ref.watch(homeModeProvider);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: _pills.map((pill) {
          final isActive = mode == pill.mode;
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: GestureDetector(
                onTap: () => ref.read(homeModeProvider.notifier).state = pill.mode,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOutCubic,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    color: isActive ? AppColors.crimson : AppColors.charcoalElevated,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: isActive
                        ? [
                            BoxShadow(
                              color: AppColors.crimson.withOpacity(0.4),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ]
                        : null,
                  ),
                  child: AnimatedDefaultTextStyle(
                    duration: const Duration(milliseconds: 250),
                    style: TextStyle(
                      color: isActive ? Colors.white : AppColors.textSecondary,
                      fontWeight: isActive ? FontWeight.w700 : FontWeight.w400,
                      fontSize: 12,
                    ),
                    child: Text(
                      pill.label,
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _MoviesFeed extends ConsumerWidget {
  const _MoviesFeed();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final hero = ref.watch(moviesHeroProvider);
    final trending = ref.watch(trendingMoviesDayProvider);
    final bollywood = ref.watch(bollywoodDhamakaProvider);
    final pakistani = ref.watch(pakistaniCinemaProvider);
    final action = ref.watch(hollywoodActionHitsProvider);

    return RefreshIndicator(
      color: AppColors.crimson,
      backgroundColor: AppColors.charcoal,
      onRefresh: () async {
        ref.invalidate(moviesHeroProvider);
        ref.invalidate(trendingMoviesDayProvider);
        ref.invalidate(bollywoodDhamakaProvider);
        ref.invalidate(pakistaniCinemaProvider);
        ref.invalidate(hollywoodActionHitsProvider);
      },
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: hero.when(
              data: (items) => MediaHeroCarousel(items: items),
              loading: () => const SizedBox(
                height: 460,
                child: Center(child: CircularProgressIndicator(color: AppColors.crimson)),
              ),
              error: (e, _) => _ErrorBanner(message: e.toString()),
            ),
          ),
          SliverToBoxAdapter(
            child: trending.when(
              data: (movies) =>
                  MediaCarousel(title: 'Trending Now', items: MediaItem.fromMovies(movies)),
              loading: () => const MediaCarousel(title: 'Trending Now', items: [], isLoading: true),
              error: (_, __) => const SizedBox.shrink(),
            ),
          ),
          SliverToBoxAdapter(
            child: bollywood.when(
              data: (movies) =>
                  MediaCarousel(title: 'Bollywood Dhamaka', items: MediaItem.fromMovies(movies)),
              loading: () => const MediaCarousel(title: 'Bollywood Dhamaka', items: [], isLoading: true),
              error: (_, __) => const SizedBox.shrink(),
            ),
          ),
          SliverToBoxAdapter(
            child: pakistani.when(
              data: (movies) =>
                  MediaCarousel(title: 'Pakistani Cinema', items: MediaItem.fromMovies(movies)),
              loading: () => const MediaCarousel(title: 'Pakistani Cinema', items: [], isLoading: true),
              error: (_, __) => const SizedBox.shrink(),
            ),
          ),
          SliverToBoxAdapter(
            child: action.when(
              data: (movies) =>
                  MediaCarousel(title: 'Hollywood Action Hits', items: MediaItem.fromMovies(movies)),
              loading: () =>
                  const MediaCarousel(title: 'Hollywood Action Hits', items: [], isLoading: true),
              error: (_, __) => const SizedBox.shrink(),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 32)),
        ],
      ),
    );
  }
}

class _SeriesFeed extends ConsumerWidget {
  const _SeriesFeed();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final hero = ref.watch(seriesHeroProvider);
    final trending = ref.watch(trendingShowsProvider);
    final pakistaniDramas = ref.watch(pakistaniDramasProvider);
    final kDrama = ref.watch(kDramaProvider);
    final turkish = ref.watch(turkishSeriesProvider);
    final topGlobal = ref.watch(topGlobalSeriesProvider);

    return RefreshIndicator(
      color: AppColors.crimson,
      backgroundColor: AppColors.charcoal,
      onRefresh: () async {
        ref.invalidate(seriesHeroProvider);
        ref.invalidate(trendingShowsProvider);
        ref.invalidate(pakistaniDramasProvider);
        ref.invalidate(kDramaProvider);
        ref.invalidate(turkishSeriesProvider);
        ref.invalidate(topGlobalSeriesProvider);
      },
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: hero.when(
              data: (items) => MediaHeroCarousel(items: items),
              loading: () => const SizedBox(
                height: 460,
                child: Center(child: CircularProgressIndicator(color: AppColors.crimson)),
              ),
              error: (e, _) => _ErrorBanner(message: e.toString()),
            ),
          ),
          SliverToBoxAdapter(
            child: trending.when(
              data: (shows) =>
                  MediaCarousel(title: 'Trending Shows', items: MediaItem.fromTvShows(shows)),
              loading: () => const MediaCarousel(title: 'Trending Shows', items: [], isLoading: true),
              error: (_, __) => const SizedBox.shrink(),
            ),
          ),
          SliverToBoxAdapter(
            child: pakistaniDramas.when(
              data: (shows) =>
                  MediaCarousel(title: 'Pakistani Dramas', items: MediaItem.fromTvShows(shows)),
              loading: () => const MediaCarousel(title: 'Pakistani Dramas', items: [], isLoading: true),
              error: (_, __) => const SizedBox.shrink(),
            ),
          ),
          SliverToBoxAdapter(
            child: kDrama.when(
              data: (shows) => MediaCarousel(title: 'K-Dramas', items: MediaItem.fromTvShows(shows)),
              loading: () => const MediaCarousel(title: 'K-Dramas', items: [], isLoading: true),
              error: (_, __) => const SizedBox.shrink(),
            ),
          ),
          SliverToBoxAdapter(
            child: turkish.when(
              data: (shows) =>
                  MediaCarousel(title: 'Turkish Series', items: MediaItem.fromTvShows(shows)),
              loading: () => const MediaCarousel(title: 'Turkish Series', items: [], isLoading: true),
              error: (_, __) => const SizedBox.shrink(),
            ),
          ),
          SliverToBoxAdapter(
            child: topGlobal.when(
              data: (shows) =>
                  MediaCarousel(title: 'Top Global Series', items: MediaItem.fromTvShows(shows)),
              loading: () => const MediaCarousel(title: 'Top Global Series', items: [], isLoading: true),
              error: (_, __) => const SizedBox.shrink(),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 32)),
        ],
      ),
    );
  }
}

class _AnimeFeed extends ConsumerWidget {
  const _AnimeFeed();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final hero = ref.watch(animeHeroProvider);
    final animeSeries = ref.watch(animeSeriesProvider);
    final animeMovies = ref.watch(animeMoviesProvider);
    final classics = ref.watch(animeClassicsProvider);

    return RefreshIndicator(
      color: AppColors.crimson,
      backgroundColor: AppColors.charcoal,
      onRefresh: () async {
        ref.invalidate(animeHeroProvider);
        ref.invalidate(animeSeriesProvider);
        ref.invalidate(animeMoviesProvider);
        ref.invalidate(animeClassicsProvider);
      },
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: hero.when(
              data: (items) => MediaHeroCarousel(items: items),
              loading: () => const SizedBox(
                height: 460,
                child: Center(child: CircularProgressIndicator(color: AppColors.crimson)),
              ),
              error: (e, _) => _ErrorBanner(message: e.toString()),
            ),
          ),
          SliverToBoxAdapter(
            child: animeSeries.when(
              data: (shows) =>
                  MediaCarousel(title: 'Trending Anime Series', items: MediaItem.fromTvShows(shows)),
              loading: () =>
                  const MediaCarousel(title: 'Trending Anime Series', items: [], isLoading: true),
              error: (_, __) => const SizedBox.shrink(),
            ),
          ),
          SliverToBoxAdapter(
            child: animeMovies.when(
              data: (movies) => MediaCarousel(
                  title: 'Anime Blockbuster Movies', items: MediaItem.fromMovies(movies)),
              loading: () =>
                  const MediaCarousel(title: 'Anime Blockbuster Movies', items: [], isLoading: true),
              error: (_, __) => const SizedBox.shrink(),
            ),
          ),
          SliverToBoxAdapter(
            child: classics.when(
              data: (shows) =>
                  MediaCarousel(title: 'All-Time Classic Anime', items: MediaItem.fromTvShows(shows)),
              loading: () =>
                  const MediaCarousel(title: 'All-Time Classic Anime', items: [], isLoading: true),
              error: (_, __) => const SizedBox.shrink(),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 32)),
        ],
      ),
    );
  }
}

class _ErrorBanner extends StatelessWidget {
  final String message;
  const _ErrorBanner({required this.message});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Text(
        'Could not load content.\n$message',
        style: const TextStyle(color: AppColors.textSecondary),
      ),
    );
  }
}
