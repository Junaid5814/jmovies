import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/movie_providers.dart';
import '../../widgets/hero_carousel.dart';
import '../../widgets/movie_carousel.dart';
import '../search/search_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final trending = ref.watch(trendingProvider);
    final topRated = ref.watch(topRatedProvider);
    final action = ref.watch(actionMoviesProvider);

    return Scaffold(
      backgroundColor: AppColors.pureBlack,
      body: SafeArea(
        child: RefreshIndicator(
          color: AppColors.crimson,
          backgroundColor: AppColors.charcoal,
          onRefresh: () async {
            ref.invalidate(trendingProvider);
            ref.invalidate(topRatedProvider);
            ref.invalidate(actionMoviesProvider);
          },
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(child: _buildHeader(context)),
              SliverToBoxAdapter(
                child: trending.when(
                  data: (movies) => Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: HeroCarousel(movies: movies),
                  ),
                  loading: () => const SizedBox(
                    height: 460,
                    child: Center(
                      child: CircularProgressIndicator(color: AppColors.crimson),
                    ),
                  ),
                  error: (e, _) => _ErrorBanner(message: e.toString()),
                ),
              ),
              SliverToBoxAdapter(
                child: trending.when(
                  data: (movies) => MovieCarousel(
                    title: 'Trending Now',
                    movies: movies,
                  ),
                  loading: () =>
                      const MovieCarousel(title: 'Trending Now', movies: [], isLoading: true),
                  error: (_, __) => const SizedBox.shrink(),
                ),
              ),
              SliverToBoxAdapter(
                child: action.when(
                  data: (movies) => MovieCarousel(title: 'Action', movies: movies),
                  loading: () =>
                      const MovieCarousel(title: 'Action', movies: [], isLoading: true),
                  error: (_, __) => const SizedBox.shrink(),
                ),
              ),
              SliverToBoxAdapter(
                child: topRated.when(
                  data: (movies) => MovieCarousel(title: 'Top Rated', movies: movies),
                  loading: () =>
                      const MovieCarousel(title: 'Top Rated', movies: [], isLoading: true),
                  error: (_, __) => const SizedBox.shrink(),
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 32)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              SvgPicture.asset('assets/icons/jmovies_logo.svg', height: 30),
              const SizedBox(width: 10),
              Text('Jmovies',
                  style: Theme.of(context)
                      .textTheme
                      .headlineMedium
                      ?.copyWith(fontSize: 22)),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.search_rounded, color: Colors.white, size: 26),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SearchScreen()),
            ),
          ),
        ],
      ),
    );
  }
}

class _ErrorBanner extends StatelessWidget {
  final String message;
  const _ErrorBanner({required this.message});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Text(
        'Could not load movies.\n$message',
        style: const TextStyle(color: AppColors.textSecondary),
      ),
    );
  }
}
