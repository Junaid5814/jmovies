import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/constants/api_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/movie_providers.dart';
import '../../widgets/genre_chip.dart';
import '../details/details_screen.dart';

class SearchScreen extends ConsumerStatefulWidget {
  const SearchScreen({super.key});

  @override
  ConsumerState<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends ConsumerState<SearchScreen> {
  final _controller = TextEditingController();

  static const _genres = {
    'Action': ApiConstants.genreAction,
    'Comedy': ApiConstants.genreComedy,
    'Drama': ApiConstants.genreDrama,
    'Sci-Fi': ApiConstants.genreSciFi,
    'Horror': ApiConstants.genreHorror,
    'Animation': ApiConstants.genreAnimation,
  };

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final results = ref.watch(searchResultsProvider);
    final selectedGenre = ref.watch(selectedGenreProvider);

    return Scaffold(
      backgroundColor: AppColors.pureBlack,
      appBar: AppBar(
        leading: const BackButton(color: Colors.white),
        title: Text('Search', style: Theme.of(context).textTheme.headlineMedium),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: TextField(
              controller: _controller,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Search movies…',
                hintStyle: const TextStyle(color: AppColors.textMuted),
                prefixIcon: const Icon(Icons.search, color: AppColors.textMuted),
                filled: true,
                fillColor: AppColors.charcoalElevated,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
              ),
              onChanged: (value) {
                ref.read(searchQueryProvider.notifier).state = value;
                if (value.isNotEmpty) {
                  ref.read(selectedGenreProvider.notifier).state = null;
                }
              },
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 40,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              itemCount: _genres.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (context, index) {
                final entry = _genres.entries.elementAt(index);
                final isSelected = selectedGenre == entry.value;
                return GenreChip(
                  label: entry.key,
                  selected: isSelected,
                  onTap: () {
                    _controller.clear();
                    ref.read(searchQueryProvider.notifier).state = '';
                    ref.read(selectedGenreProvider.notifier).state =
                        isSelected ? null : entry.value;
                  },
                );
              },
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: results.when(
              data: (movies) {
                if (movies.isEmpty) {
                  return const Center(
                    child: Text('Start typing or pick a genre',
                        style: TextStyle(color: AppColors.textMuted)),
                  );
                }
                return GridView.builder(
                  padding: const EdgeInsets.all(20),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 16,
                    childAspectRatio: 0.6,
                  ),
                  itemCount: movies.length,
                  itemBuilder: (context, index) {
                    final movie = movies[index];
                    return GestureDetector(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => DetailsScreen(movieId: movie.id),
                        ),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: movie.posterUrl.isEmpty
                            ? Container(color: AppColors.charcoalElevated)
                            : Image.network(movie.posterUrl, fit: BoxFit.cover),
                      ),
                    );
                  },
                );
              },
              loading: () => const Center(
                child: CircularProgressIndicator(color: AppColors.crimson),
              ),
              error: (e, _) => Center(
                child: Text('Search failed', style: const TextStyle(color: AppColors.textSecondary)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
