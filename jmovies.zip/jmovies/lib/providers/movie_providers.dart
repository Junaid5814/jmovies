import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/models/movie_model.dart';
import '../data/models/video_source_model.dart';
import '../data/repositories/movie_repository.dart';
import '../core/constants/api_constants.dart';

final movieRepositoryProvider = Provider<MovieRepository>((ref) {
  return MovieRepository();
});

// --- Home screen carousels ---

final trendingProvider = FutureProvider<List<Movie>>((ref) {
  return ref.watch(movieRepositoryProvider).getTrending();
});

final topRatedProvider = FutureProvider<List<Movie>>((ref) {
  return ref.watch(movieRepositoryProvider).getTopRated();
});

final actionMoviesProvider = FutureProvider<List<Movie>>((ref) {
  return ref
      .watch(movieRepositoryProvider)
      .getByGenre(ApiConstants.genreAction);
});

// --- Details screen ---

final movieDetailsProvider =
    FutureProvider.family<Movie, int>((ref, movieId) {
  return ref.watch(movieRepositoryProvider).getDetails(movieId);
});

final streamBundleProvider =
    FutureProvider.family<StreamBundle, int>((ref, movieId) {
  return ref.watch(movieRepositoryProvider).getStreamBundle(movieId);
});

// --- Search screen ---

final searchQueryProvider = StateProvider<String>((ref) => '');

final selectedGenreProvider = StateProvider<int?>((ref) => null);

final searchResultsProvider = FutureProvider<List<Movie>>((ref) async {
  final query = ref.watch(searchQueryProvider);
  final genre = ref.watch(selectedGenreProvider);
  final repo = ref.watch(movieRepositoryProvider);

  if (query.trim().isNotEmpty) return repo.search(query);
  if (genre != null) return repo.getByGenre(genre);
  return [];
});

// --- Player: which source (server) is currently selected ---

final selectedSourceIndexProvider = StateProvider<int>((ref) => 0);
