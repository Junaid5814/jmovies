import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/models/movie_model.dart';
import '../data/models/tv_model.dart';
import '../data/models/media_item.dart';
import '../data/models/video_source_model.dart';
import '../data/repositories/movie_repository.dart';

final movieRepositoryProvider = Provider<MovieRepository>((ref) {
  return MovieRepository();
});

/// Top-level 3-mode switch driving the Home screen feed.
enum HomeMode { movies, series, anime }

final homeModeProvider = StateProvider<HomeMode>((ref) => HomeMode.movies);

// =========================================================================
// Movies tab
// =========================================================================

final nowPlayingInCinemaProvider = FutureProvider<List<Movie>>((ref) {
  return ref.watch(movieRepositoryProvider).getNowPlayingInCinema();
});

final top10MoviesTodayProvider = FutureProvider<List<Movie>>((ref) {
  return ref.watch(movieRepositoryProvider).getTop10MoviesToday();
});

final bollywoodHitsProvider = FutureProvider<List<Movie>>((ref) {
  return ref.watch(movieRepositoryProvider).getBollywoodHits();
});

final hollywoodActionHitsProvider = FutureProvider<List<Movie>>((ref) {
  return ref.watch(movieRepositoryProvider).getHollywoodActionHits();
});

/// Hero banner source for the Movies tab.
final moviesHeroProvider = FutureProvider<List<MediaItem>>((ref) async {
  final movies = await ref.watch(nowPlayingInCinemaProvider.future);
  return MediaItem.fromMovies(movies);
});

// =========================================================================
// Series & Dramas tab
// =========================================================================

final top10SeriesTodayProvider = FutureProvider<List<TvShow>>((ref) {
  return ref.watch(movieRepositoryProvider).getTop10SeriesToday();
});

final pakistaniDramasProvider = FutureProvider<List<TvShow>>((ref) {
  return ref.watch(movieRepositoryProvider).getPakistaniDramas();
});

final turkishDramasProvider = FutureProvider<List<TvShow>>((ref) {
  return ref.watch(movieRepositoryProvider).getTurkishDramas();
});

final kDramaProvider = FutureProvider<List<TvShow>>((ref) {
  return ref.watch(movieRepositoryProvider).getKDramas();
});

final netflixOriginalsProvider = FutureProvider<List<TvShow>>((ref) {
  return ref.watch(movieRepositoryProvider).getNetflixOriginals();
});

final primeVideoProvider = FutureProvider<List<TvShow>>((ref) {
  return ref.watch(movieRepositoryProvider).getAmazonPrimeVideo();
});

final hboMaxProvider = FutureProvider<List<TvShow>>((ref) {
  return ref.watch(movieRepositoryProvider).getHboMaxExclusives();
});

final disneyHotstarProvider = FutureProvider<List<TvShow>>((ref) {
  return ref.watch(movieRepositoryProvider).getDisneyHotstar();
});

/// Hero banner source for the Series & Dramas tab.
final seriesHeroProvider = FutureProvider<List<MediaItem>>((ref) async {
  final shows = await ref.watch(top10SeriesTodayProvider.future);
  return MediaItem.fromTvShows(shows);
});

// =========================================================================
// Anime tab
// =========================================================================

final trendingAnimeProvider = FutureProvider<List<TvShow>>((ref) {
  return ref.watch(movieRepositoryProvider).getTrendingAnime();
});

final animeMoviesProvider = FutureProvider<List<Movie>>((ref) {
  return ref.watch(movieRepositoryProvider).getAnimeMovies();
});

/// Hero banner source for the Anime tab.
final animeHeroProvider = FutureProvider<List<MediaItem>>((ref) async {
  final shows = await ref.watch(trendingAnimeProvider.future);
  return MediaItem.fromTvShows(shows);
});

// =========================================================================
// Details screens
// =========================================================================

final movieDetailsProvider =
    FutureProvider.family<Movie, int>((ref, movieId) {
  return ref.watch(movieRepositoryProvider).getMovieDetails(movieId);
});

final tvDetailsProvider = FutureProvider.family<TvShow, int>((ref, tvId) {
  return ref.watch(movieRepositoryProvider).getTvDetails(tvId);
});

/// Currently selected season number on the Details screen (TV/anime), per TV ID.
final selectedSeasonProvider =
    StateProvider.family<int, int>((ref, tvId) => 1);

final seasonDetailProvider = FutureProvider.family<SeasonDetail, ({int tvId, int season})>(
  (ref, args) {
    return ref
        .watch(movieRepositoryProvider)
        .getSeasonDetail(args.tvId, args.season);
  },
);

// =========================================================================
// Streaming
// =========================================================================

final movieStreamBundleProvider =
    FutureProvider.family<StreamBundle, int>((ref, movieId) {
  return ref.watch(movieRepositoryProvider).getMovieStreamBundle(movieId);
});

final episodeStreamBundleProvider = FutureProvider.family<StreamBundle,
    ({int tvId, int season, int episode})>((ref, args) {
  return ref
      .watch(movieRepositoryProvider)
      .getEpisodeStreamBundle(args.tvId, args.season, args.episode);
});

// =========================================================================
// Search screen
// =========================================================================

final searchQueryProvider = StateProvider<String>((ref) => '');
final selectedGenreProvider = StateProvider<int?>((ref) => null);

final searchResultsProvider = FutureProvider<List<Movie>>((ref) async {
  final query = ref.watch(searchQueryProvider);
  final genre = ref.watch(selectedGenreProvider);
  final repo = ref.watch(movieRepositoryProvider);

  if (query.trim().isNotEmpty) return repo.searchMovies(query);
  if (genre != null) return repo.getMoviesByGenre(genre);
  return [];
});

// =========================================================================
// Player: which source (server) is currently selected
// =========================================================================

final selectedSourceIndexProvider = StateProvider<int>((ref) => 0);
