import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/models/movie_model.dart';
import '../data/models/tv_model.dart';
import '../data/models/media_item.dart';
import '../data/models/video_source_model.dart';
import '../data/repositories/movie_repository.dart';
import '../core/constants/api_constants.dart';

final movieRepositoryProvider = Provider<MovieRepository>((ref) {
  return MovieRepository();
});

/// Top-level 3-mode switch driving the Home screen feed.
enum HomeMode { movies, series, anime }

final homeModeProvider = StateProvider<HomeMode>((ref) => HomeMode.movies);

// =========================================================================
// Mode 1: Movies
// =========================================================================

final trendingMoviesDayProvider = FutureProvider<List<Movie>>((ref) {
  return ref.watch(movieRepositoryProvider).getTrendingMoviesDay();
});

final bollywoodDhamakaProvider = FutureProvider<List<Movie>>((ref) {
  return ref
      .watch(movieRepositoryProvider)
      .getMoviesByLanguage(ApiConstants.langHindi);
});

final pakistaniCinemaProvider = FutureProvider<List<Movie>>((ref) {
  return ref
      .watch(movieRepositoryProvider)
      .getMoviesByOriginCountry(ApiConstants.countryPakistan);
});

final hollywoodActionHitsProvider = FutureProvider<List<Movie>>((ref) {
  return ref
      .watch(movieRepositoryProvider)
      .getMoviesByGenre(ApiConstants.genreAction);
});

final moviesHeroProvider = FutureProvider<List<MediaItem>>((ref) async {
  final movies = await ref.watch(trendingMoviesDayProvider.future);
  return MediaItem.fromMovies(movies);
});

// =========================================================================
// Mode 2: Series & Dramas
// =========================================================================

final trendingShowsProvider = FutureProvider<List<TvShow>>((ref) {
  return ref.watch(movieRepositoryProvider).getTrendingTv();
});

final pakistaniDramasProvider = FutureProvider<List<TvShow>>((ref) {
  return ref.watch(movieRepositoryProvider).getTvByOriginCountry(
        ApiConstants.countryPakistan,
        languageCode: ApiConstants.langUrdu,
      );
});

final kDramaProvider = FutureProvider<List<TvShow>>((ref) {
  return ref
      .watch(movieRepositoryProvider)
      .getTvByOriginCountry(ApiConstants.countrySouthKorea);
});

final turkishSeriesProvider = FutureProvider<List<TvShow>>((ref) {
  return ref
      .watch(movieRepositoryProvider)
      .getTvByOriginCountry(ApiConstants.countryTurkey);
});

final topGlobalSeriesProvider = FutureProvider<List<TvShow>>((ref) {
  return ref.watch(movieRepositoryProvider).getTopRatedTv();
});

final seriesHeroProvider = FutureProvider<List<MediaItem>>((ref) async {
  final shows = await ref.watch(trendingShowsProvider.future);
  return MediaItem.fromTvShows(shows);
});

// =========================================================================
// Mode 3: Anime
// =========================================================================

final animeSeriesProvider = FutureProvider<List<TvShow>>((ref) {
  return ref.watch(movieRepositoryProvider).getTvByGenreLanguage(
        ApiConstants.genreAnimation,
        ApiConstants.langJapanese,
      );
});

final animeMoviesProvider = FutureProvider<List<Movie>>((ref) {
  return ref
      .watch(movieRepositoryProvider)
      .getMoviesByGenreLanguage(ApiConstants.genreAnimation, ApiConstants.langJapanese);
});

final animeClassicsProvider = FutureProvider<List<TvShow>>((ref) {
  return ref.watch(movieRepositoryProvider).getTvByGenreLanguage(
        ApiConstants.genreAnimation,
        ApiConstants.langJapanese,
        sortBy: 'vote_average.desc',
        minVoteCount: 300,
      );
});

final animeHeroProvider = FutureProvider<List<MediaItem>>((ref) async {
  final shows = await ref.watch(animeSeriesProvider.future);
  return MediaItem.fromTvShows(shows);
});

// =========================================================================
// OTT platform rows (kept from the previous TV tab; still used on the
// Series & Dramas mode alongside the new rows above).
// =========================================================================

final netflixOriginalsProvider = FutureProvider<List<TvShow>>((ref) {
  return ref
      .watch(movieRepositoryProvider)
      .getTvByNetwork(ApiConstants.networkNetflix);
});

final primeVideoProvider = FutureProvider<List<TvShow>>((ref) {
  return ref
      .watch(movieRepositoryProvider)
      .getTvByNetwork(ApiConstants.networkAmazonPrime);
});

// =========================================================================
// Details screens
// =========================================================================

final movieDetailsProvider =
    FutureProvider.family<Movie, int>((ref, movieId) {
  return ref.watch(movieRepositoryProvider).getMovieDetails(movieId);
});

final tvDetailsProvider = FutureProvider.family<TvShow, int>((ref, tvId) {
  return ref.watch(movieRepositoryProvider).getTvDetails(tvId);
});

/// Currently selected season number on the Details screen (TV/anime), per TV ID.
final selectedSeasonProvider =
    StateProvider.family<int, int>((ref, tvId) => 1);

final seasonDetailProvider = FutureProvider.family<SeasonDetail, ({int tvId, int season})>(
  (ref, args) {
    return ref
        .watch(movieRepositoryProvider)
        .getSeasonDetail(args.tvId, args.season);
  },
);

// =========================================================================
// Streaming
// =========================================================================

final movieStreamBundleProvider =
    FutureProvider.family<StreamBundle, int>((ref, movieId) {
  return ref.watch(movieRepositoryProvider).getMovieStreamBundle(movieId);
});

final episodeStreamBundleProvider = FutureProvider.family<StreamBundle,
    ({int tvId, int season, int episode})>((ref, args) {
  return ref
      .watch(movieRepositoryProvider)
      .getEpisodeStreamBundle(args.tvId, args.season, args.episode);
});

// =========================================================================
// Search screen
// =========================================================================

final searchQueryProvider = StateProvider<String>((ref) => '');
final selectedGenreProvider = StateProvider<int?>((ref) => null);

final searchResultsProvider = FutureProvider<List<Movie>>((ref) async {
  final query = ref.watch(searchQueryProvider);
  final genre = ref.watch(selectedGenreProvider);
  final repo = ref.watch(movieRepositoryProvider);

  if (query.trim().isNotEmpty) return repo.searchMovies(query);
  if (genre != null) return repo.getMoviesByGenre(genre);
  return [];
});

// =========================================================================
// Player: which source (server) is currently selected
// =========================================================================

final selectedSourceIndexProvider = StateProvider<int>((ref) => 0);
